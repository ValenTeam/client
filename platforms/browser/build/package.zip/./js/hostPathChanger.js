/**
 * Created by felipeplazas on 4/27/17.
 */
$(document).ready(function() {
    window.hostUrl = "http://www.hospital-arquisoft.top";
});